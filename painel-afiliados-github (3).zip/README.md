# Painel de Afiliados
Este é um painel de exemplo para afiliados.